import { useEffect, useState } from 'react';
import { api, API_MODE } from './lib/api.js';
import { useApi } from './lib/useApi.js';
import { mockSession } from './mocks/index.js';
import { Sidebar, Topbar, navFor } from './components/Shell.jsx';
import { Loading, ErrorState } from './components/states.jsx';
import Ringkasan from './pages/Ringkasan.jsx';
import Keuangan from './pages/Keuangan.jsx';
import Stok from './pages/Stok.jsx';
import Gudang from './pages/Gudang.jsx';
import Sinkron from './pages/Sinkron.jsx';

const PAGES = {
  ringkasan: { kicker: 'Penjualan', title: 'Ringkasan',            Component: Ringkasan },
  keuangan:  { kicker: 'Keuangan',  title: 'Rincian keuangan',     Component: Keuangan },
  stok:      { kicker: 'Gudang',    title: 'Stok & produk',        Component: Stok },
  gudang:    { kicker: 'Gudang',    title: 'Daftar kirim',         Component: Gudang },
  sinkron:   { kicker: 'Sistem',    title: 'Status sinkronisasi',  Component: Sinkron },
};

/* Peran ditentukan server lewat /me. Pengalih di bawah hanya untuk mode mock,
   supaya klien bisa melihat perbedaan tampilan tiap peran. Hapus DevBar
   sebelum produksi. */
function DevBar({ role, onRole }) {
  if (API_MODE !== 'mock') return null;
  return (
    <div className="devbar">
      <strong style={{ fontWeight: 600 }}>Mode contoh</strong>
      <span style={{ opacity: .7 }}>data dari src/mocks · tanpa backend</span>
      <label style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
        Lihat sebagai
        <select value={role} onChange={(e) => onRole(e.target.value)}>
          <option value="finance">Finance</option>
          <option value="sales">Sales</option>
          <option value="warehouse">Gudang</option>
          <option value="admin">Admin</option>
        </select>
      </label>
      <span className="grow">Set VITE_API_MODE=http untuk memakai backend</span>
    </div>
  );
}

export default function App() {
  const [role, setRole] = useState(mockSession.role);
  const [page, setPage] = useState('keuangan');

  const me = useApi(api.me, { role });          // role masuk key agar mock ikut berubah
  const sync = useApi(api.syncState, { role });

  // Kalau halaman aktif tidak lagi berwenang, pindah ke halaman pertama yang sah.
  useEffect(() => {
    const allowed = navFor(role).flatMap((g) => g.items.map((i) => i.id));
    if (!allowed.includes(page)) setPage(allowed[0]);
  }, [role, page]);

  function changeRole(next) {
    mockSession.role = next;   // hanya berpengaruh di mode mock
    setRole(next);
  }

  if (me.status === 'loading') return <div style={{ padding: 40 }}><Loading rows={4} /></div>;
  if (me.status === 'error') return <div style={{ padding: 40 }}><ErrorState error={me.error} onRetry={me.reload} /></div>;

  const { Component, kicker, title } = PAGES[page] ?? PAGES.ringkasan;

  return (
    <>
      <DevBar role={role} onRole={changeRole} />
      <div className="shell">
        <Sidebar role={role} user={me.data.user} shop={me.data.shop} page={page} onNavigate={setPage} />
        <main className="main">
          <Topbar kicker={kicker} title={title} sync={sync.data}
                  onExport={() => alert('Panel export CSV — dibangun pada Fase 5.')} />
          <Component role={role} />
        </main>
      </div>
    </>
  );
}
