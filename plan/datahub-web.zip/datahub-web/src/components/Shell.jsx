import { Icon } from './primitives.jsx';
import { relativeFromNow } from '../lib/format.js';

const NAV = [
  { group: 'Operasional', items: [
    { id: 'ringkasan', name: 'Ringkasan',  icon: 'dashboard',    roles: ['sales', 'finance', 'admin'] },
    { id: 'keuangan',  name: 'Keuangan',   icon: 'account_balance', roles: ['finance', 'admin'] },
    { id: 'stok',      name: 'Stok',       icon: 'inventory_2',  roles: ['sales', 'warehouse', 'admin'] },
    { id: 'gudang',    name: 'Daftar kirim', icon: 'local_shipping', roles: ['warehouse', 'admin'] },
  ]},
  { group: 'Sistem', items: [
    { id: 'sinkron', name: 'Status sinkronisasi', icon: 'sync', roles: ['admin'] },
  ]},
];

export function navFor(role) {
  return NAV.map((g) => ({ ...g, items: g.items.filter((i) => i.roles.includes(role)) }))
           .filter((g) => g.items.length > 0);
}

export function Sidebar({ role, user, shop, page, onNavigate }) {
  return (
    <aside className="side">
      <div className="side-head">
        <div className="side-logo"><Icon name="hub" size={21} /></div>
        <div style={{ minWidth: 0 }}>
          <span className="side-title">Data Hub</span>
          <span className="side-sub">Shopee · {shop?.name ?? '—'}</span>
        </div>
      </div>

      <div className="side-user">
        <span className="av">{user?.initials}</span>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 700, lineHeight: 1.2 }}>{user?.name}</div>
          <div className="side-sub">{user?.role_label}</div>
        </div>
      </div>

      {/* Menu di luar wewenang tidak dirender sama sekali — bukan dimatikan. */}
      <nav className="side-nav">
        {navFor(role).map((g) => (
          <div key={g.group}>
            <div className="side-group">{g.group}</div>
            {g.items.map((item) => (
              <button
                key={item.id}
                className="side-item"
                aria-current={page === item.id ? 'page' : undefined}
                onClick={() => onNavigate(item.id)}
              >
                <span className="chip"><Icon name={item.icon} size={17} /></span>
                <span style={{ flex: 1 }}>{item.name}</span>
              </button>
            ))}
          </div>
        ))}
      </nav>

      <div className="side-foot">
        <span>Data Hub © 2026</span>
        <span className="mono">v0.1</span>
      </div>
    </aside>
  );
}

export function FreshnessPill({ sync }) {
  if (!sync) return null;
  const stale = sync.is_stale;
  return (
    <div className={`pill${stale ? ' warn' : ''}`} title={stale ? 'Sinkronisasi tertunda' : 'Sinkronisasi normal'}>
      <Icon name={stale ? 'sync_problem' : 'cloud_done'} size={16}
            color={stale ? 'var(--warning)' : 'var(--success)'} />
      <span>Sinkron <span className="mono">{relativeFromNow(sync.last_success_at)}</span></span>
    </div>
  );
}

export function Topbar({ kicker, title, sync, onExport }) {
  return (
    <header className="topbar">
      <div style={{ minWidth: 0 }}>
        <div className="kicker">{kicker}</div>
        <h1>{title}</h1>
      </div>
      <div className="right">
        <FreshnessPill sync={sync} />
        <button className="btn" onClick={onExport}>
          <Icon name="download" size={16} /> Export CSV
        </button>
      </div>
    </header>
  );
}
