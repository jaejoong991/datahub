import { api } from '../lib/api.js';
import { useApi } from '../lib/useApi.js';
import { Async } from '../components/states.jsx';
import { DataTable } from '../components/DataTable.jsx';
import { Card, KpiCard, Icon, Money } from '../components/primitives.jsx';
import { formatCompactIDR, formatCount, formatDateWIB } from '../lib/format.js';

export default function Ringkasan({ role }) {
  const summary = useApi(api.salesSummary, {});
  const trend = useApi(api.salesTrend, {});
  const top = useApi(api.topProducts, {});
  const showMoney = role !== 'warehouse';

  return (
    <div className="page">
      <Async query={summary} loadingRows={3}>
        {(d) => (
          <div className="kpis">
            <KpiCard icon="payments" color="var(--info)" label="Bruto penjualan"
                     value={showMoney ? formatCompactIDR(d.gross) : '—'} sub="periode berjalan" delta={d.deltas.gross} />
            <KpiCard icon="receipt_long" color="var(--warning)" label="Jumlah order"
                     value={formatCount(d.order_count)} sub="periode berjalan" delta={d.deltas.order_count} />
            <KpiCard icon="shopping_bag" color="var(--primary)" label="Rata-rata nilai order"
                     value={showMoney ? formatCompactIDR(d.average_order_value) : '—'} delta={d.deltas.average_order_value} />
            <KpiCard icon="inventory" color="var(--success)" label="Item terjual"
                     value={formatCount(d.items_sold)} delta={d.deltas.items_sold} />
          </div>
        )}
      </Async>

      <div className="grid-2">
        <Card>
          <div className="card-head">
            <div style={{ flex: 1 }}>
              <h2>Tren penjualan harian</h2>
              <span className="card-note">Bruto per hari, dikelompokkan menurut tanggal WIB.</span>
            </div>
          </div>
          <Async query={trend} isEmpty={(d) => d.rows.length === 0} loadingRows={7}>
            {(d) => (
              <div className="bars">
                {d.rows.map((r) => (
                  <div className="row" key={r.report_date}>
                    <span className="lab">{formatDateWIB(r.report_date).slice(0, 6)}</span>
                    <div className="track">
                      <div className="fill" style={{ width: `${Math.round((r.gross / d.max) * 100)}%` }} />
                    </div>
                    <span className="val">{showMoney ? <Money value={r.gross} /> : '—'}</span>
                  </div>
                ))}
              </div>
            )}
          </Async>
        </Card>

        <Card>
          <div className="card-head">
            <div style={{ flex: 1 }}>
              <h2>Produk terlaris</h2>
              <span className="card-note">Berdasarkan qty terjual.</span>
            </div>
          </div>
          <Async query={top} isEmpty={(d) => d.rows.length === 0}>
            {(d) => <DataTable columns={d.columns} rows={d.rows} minWidth={420} rowKey="sku" />}
          </Async>
        </Card>
      </div>

      <div className="legend">
        <Icon name="info" size={15} />
        <span>
          Bruto berasal dari tabel order. Payout bersih hanya boleh dibaca dari halaman Keuangan,
          karena sumbernya data settlement yang datang belakangan.
        </span>
      </div>
    </div>
  );
}
